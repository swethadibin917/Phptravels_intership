package com.phptravels.customer.end;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Customer_Address {

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\91999\\Downloads\\chromedriver-116\\chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.get("https://www.phptravels.net/login");
	driver.manage().window().maximize();
	//vaild email and password
			Thread.sleep(2000);
	    //Thread.sleep(3000);
	    driver.get("https://www.phptravels.net/login");
		driver.manage().window().maximize();
		//1)Login using the credentials. Check for valid and invalid test cases		
	   //valid email and password
		//click Account button
		driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/div[2]/ul/li[3]/a/strong")).click();
	  //click login button
		driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/div[2]/ul/li[3]/ul/li[1]/a")).click();
		Thread.sleep(2000);
		WebElement email=driver.findElement(By.id("email"));
		email.sendKeys("user@phptravels.com");
		WebElement pwd=driver.findElement(By.id("password"));
		pwd.sendKeys("demouser");
		Thread.sleep(2000);
		WebElement login=driver.findElement(By.id("submitBTN"));
		login.click();
		System.out.println("login successfully");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div[2]/ul/li[3]/a\r\n")).click();
		driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("demouser");
	    driver.findElement(By.xpath("/html/body/div[1]/div/section[1]/div/div/div/div/div/div[2]/form/div/div[6]/button")).click();
	    Thread.sleep(2000);
        driver.quit();

	}

}
