package com.phptravels.customer.end;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Customer_Booking_Vou {

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\91999\\Downloads\\chromedriver-116\\chromedriver.exe");
		WebDriver driver = new ChromeDriver(); 
		driver.get("https://www.phptravels.net/login");
		driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	//valid email and password
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("user@phptravels.com");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("demouser");
		driver.findElement(By.xpath("//button[@id='submitBTN']")).click();
		Thread.sleep(3000);
		System.out.println("login successfully");
	//MyBookings
		Thread.sleep(2000);
		WebElement Mybooking=driver.findElement(By.xpath("//*[@id=\"fadein\"]/div[1]/div/div/div[2]/ul/li[2]/a"));
		Mybooking.click();
		Thread.sleep(2000);
	//Invoice	
		driver.findElement(By.xpath("//table[@class='table table-striped table-bordered dataTable no-footer']//tbody//tr//td//a")).click();
		Thread.sleep(3000);
		Set<String> WindowHandles = driver.getWindowHandles();
		for(String winhnd:WindowHandles)
		{
			String hndl = driver.switchTo().window(winhnd).getTitle();
			if(hndl.equals("Hotels Invoice"))
			{
				System.out.println("Booking invoice displayed");
			}
		}
		
		Thread.sleep(3000);
;
	}

}
