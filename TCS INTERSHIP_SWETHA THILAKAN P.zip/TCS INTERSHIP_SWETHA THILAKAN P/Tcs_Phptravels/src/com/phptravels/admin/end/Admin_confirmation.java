package com.phptravels.admin.end;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class Admin_confirmation {

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\91999\\Downloads\\chromedriver-116\\chromedriver.exe");
		WebDriver driver = new ChromeDriver(); 
		    Thread.sleep(3000);
		    driver.get("https://phptravels.net/admin/login.php");
			driver.manage().window().maximize();
			driver.findElement(By.xpath("//input[@id='email']")).sendKeys("admin@phptravels.com");
			driver.findElement(By.xpath("//input[@id='password']")).sendKeys("demoadmin");
			driver.findElement(By.xpath("//button[@id='submit']")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("/html/body/main/header/ul/li[10]/a")).click();
			driver.findElement(By.cssSelector("html body main section.w-100 div.mt-1 div.p-3 div.card.p-3.mb-2 form#search.row.g-2 div.col-md-2 div.form-floating select#search_type.form-select.booking_status")).click();
			driver.findElement(By.xpath("//*[@id=\"search_type\"]")).click();
		    driver.findElement(By.xpath("/html/body/main/section/div[2]/div/div/form/div[3]/div/select/option[3]")).click();
			
		    driver.findElement(By.xpath("//*[@id=\"search_type\"]")).click();
		    driver.findElement(By.xpath("/html/body/main/section/div[2]/div/div/form/div[2]/div/select/option[4]")).click();
			
		    driver.findElement(By.xpath("//*[@id=\"search_type\"]")).click();
		    driver.findElement(By.xpath("/html/body/main/section/div[2]/div/div/form/div[4]/div/select/option[2]")).click();
			
		    driver.findElement(By.xpath("/html/body/main/section/div[2]/div/div/form/div[5]/div/input")).click();
		    driver.findElement(By.xpath("/html/body/div[2]/div[1]/table/tbody/tr[2]/td[3]")).click();
			driver.findElement(By.xpath("/html/body/main/section/div[2]/div/div/form/div[6]/button")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id=\"dropdownUser1\"]")).click();
			driver.findElement(By.xpath("/html/body/main/header/div[2]/ul/li[1]/a")).click();
			Thread.sleep(2000);
			driver.close();
	}

}
