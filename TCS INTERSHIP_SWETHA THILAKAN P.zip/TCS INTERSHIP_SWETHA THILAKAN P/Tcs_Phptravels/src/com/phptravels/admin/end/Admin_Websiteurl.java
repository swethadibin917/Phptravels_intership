package com.phptravels.admin.end;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Admin_Websiteurl {

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\91999\\Downloads\\chromedriver-116\\chromedriver.exe");
		WebDriver driver = new ChromeDriver(); 
	    Thread.sleep(3000);
	    driver.get("https://phptravels.net/admin/login.php");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("admin@phptravels.com");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("demoadmin");
		driver.findElement(By.xpath("//button[@id='submit']")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.cssSelector("html body main header.d-flex.flex-column.flex-shrink-0.text-white.sidebar div.p-3.d-flex.items-align-center.justify-content-between.border-bottom.pb-3.mb-3 a svg g path")).click();
		Thread.sleep(2000);
		String parentwindow=driver.getWindowHandle();
		Set<String> allwindow=driver.getWindowHandles();
	    Iterator<String> s=allwindow.iterator();
	    while(s.hasNext())
	    	{
	    	
	          String cwindow=s.next();
	          if(!parentwindow.equals(cwindow)) 
	          {
	        	  driver.switchTo().window(cwindow);
	          }
	    	}
	    
	    System.out.println(driver.getCurrentUrl());
		
		Thread.sleep(3000);

		driver.quit();
	}

}
