package com.phptravels.admin.end;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Admin_Pendingtocnfrm {

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\91999\\Downloads\\chromedriver-116\\chromedriver.exe");
		WebDriver driver = new ChromeDriver(); 
	    Thread.sleep(3000);
	    driver.get("https://phptravels.net/admin/login.php");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("admin@phptravels.com");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("demoadmin");
		driver.findElement(By.xpath("//button[@id='submit']")).click();
		Thread.sleep(2000);
	
		
		driver.findElement(By.xpath("//a[normalize-space()='Bookings']")).click();
	

	
		WebElement BookingStats = driver.findElement(By.xpath("//select[@name='booking_status']"));
		
		Select sl = new Select(BookingStats);
		sl.selectByVisibleText("Pending");
		
		WebElement PaymentStats = driver.findElement(By.xpath("//select[@name='payment_status']"));
		
		Select s2 = new Select(PaymentStats);
		s2.selectByVisibleText("Unpaid");
		
		driver.findElement(By.xpath("//button[normalize-space()='Search']")).click();
		
		Thread.sleep(3000);
	
		driver.findElement(By.xpath("//a[normalize-space()='Booking Details']")).click();
		
		Set<String> windowHandles = driver.getWindowHandles();
		
		List<String> Winhandles = new ArrayList<String>(windowHandles);
		
		
		String parWindow = Winhandles.get(0);
		String newWindow = Winhandles.get(1);
		
		driver.switchTo().window(newWindow);
		Thread.sleep(3000);
	
	
		driver.findElement(By.xpath("//input[@id='form']")).click();
		Thread.sleep(3000);
	
		
		driver.switchTo().window(parWindow);
		
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//span[@class='fw-semibold']")).click();
		
		String count  = driver.findElement(By.xpath("/html/body/main/section/div[2]/div[1]/div[3]/div/div/div/div[1]/div[2]")).getText();
		System.out.println("Total count: "+count);
		
		driver.close();

	}

}
