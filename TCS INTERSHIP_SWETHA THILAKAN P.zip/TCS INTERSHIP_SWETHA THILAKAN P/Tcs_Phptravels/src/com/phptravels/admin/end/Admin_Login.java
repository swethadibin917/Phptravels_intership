package com.phptravels.admin.end;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class Admin_Login {

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\91999\\Downloads\\chromedriver-116\\chromedriver.exe");
		WebDriver driver = new ChromeDriver(); 
	    Thread.sleep(3000);
	    driver.get("https://phptravels.net/admin/login.php");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("admin@phptravels.com");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("demoadmin");
		driver.findElement(By.xpath("//button[@id='submit']")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("#dropdownUser1")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/main/header/div[2]/ul/li[6]/a")).click();
		Thread.sleep(2000);
		
		//invalidcase
			driver.findElement(By.xpath("//input[@id='email']")).sendKeys("admin@phptravels.com");
			driver.findElement(By.xpath("//input[@id='password']")).sendKeys("demo");
			driver.findElement(By.xpath("//button[@id='submit']")).click();
			System.out.println("please check your email and password..");
		    Thread.sleep(2000);
		
		//invalidcase
			 driver.findElement(By.xpath("//input[@name='email']")).click();
			 driver.findElement(By.xpath("//input[@name='password']")).click();
			 driver.findElement(By.xpath("//select[@class='text-dark']")).sendKeys("English");
			 driver.findElement(By.xpath("//button[@id='submit']")).click();
			 System.out.println("please check your email and password..");
			driver.close();


	}

}
