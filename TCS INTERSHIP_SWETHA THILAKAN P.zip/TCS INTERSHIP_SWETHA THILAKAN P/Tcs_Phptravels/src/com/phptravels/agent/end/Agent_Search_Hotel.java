package com.phptravels.agent.end;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Agent_Search_Hotel {

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\91999\\Downloads\\chromedriver-116\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.phptravels.net/login");
		driver.manage().window().maximize();
		
//4)Script to search hotels by city and test results.
	
		//valid email and password
		Thread.sleep(2000);
		WebElement email=driver.findElement(By.id("email"));
		email.sendKeys("agent@phptravels.com");
		WebElement pwd=driver.findElement(By.id("password"));
		pwd.sendKeys("demoagent");
		Thread.sleep(2000);
		WebElement login=driver.findElement(By.id("submitBTN"));
		login.click();
	
		//Click Hotels
		Thread.sleep(2000);
		WebElement hotel=driver.findElement(By.cssSelector("#navbarSupportedContent > div.nav-item--left.ms-lg-5 > ul > li:nth-child(2) > a"));
		hotel.click();
	
		//Select city
		WebElement city=driver.findElement(By.xpath("//span[@class='select2-selection__rendered']"));
		city.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//body/span[1]/span[1]/span[2]/ul[1]/div[1]/div[1]")).click();
		Thread.sleep(2000);
	
		//click search button
		WebElement search=driver.findElement(By.xpath("//button[@type='submit']"));
		search.click();
		Thread.sleep(2000);
		driver.quit();


	}

}
