package com.phptravels.agent.end;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class Agent_Usd_Inr {

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\91999\\Downloads\\chromedriver-116\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
        driver.get("https://www.phptravels.net/login");
		driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//Develop the script that would update USD to INR for the account.
	//valid email and password
		Thread.sleep(2000);
		WebElement email=driver.findElement(By.id("email"));
		email.sendKeys("agent@phptravels.com");
		WebElement pwd=driver.findElement(By.id("password"));
		pwd.sendKeys("demoagent");
		Thread.sleep(2000);
		WebElement login=driver.findElement(By.id("submitBTN"));
		login.click();
	//Click USD
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/header/div/div[2]/div[2]/ul/li[2]/a")).click();
		
	//select INR
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/header/div/div[2]/div[2]/ul/li[2]/ul/li[4]/a")).click();
		
		Thread.sleep(2000);
		driver.close();
		

	}

}
