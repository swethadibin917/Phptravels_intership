package com.phptravels.agent.end;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Agent_Destination_links {

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\91999\\Downloads\\chromedriver-116\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.phptravels.net/login");
		driver.manage().window().maximize();
//
	//Home
		Thread.sleep(2000);
		WebElement email=driver.findElement(By.id("email"));
		email.sendKeys("agent@phptravels.com");
		WebElement pwd=driver.findElement(By.id("password"));
		pwd.sendKeys("demoagent");
		Thread.sleep(2000);
		WebElement login=driver.findElement(By.id("submitBTN"));
		login.click();
	//Flights
		Thread.sleep(2000);
		WebElement flights=driver.findElement(By.cssSelector("#navbarSupportedContent > div.nav-item--left.ms-lg-5 > ul > li:nth-child(1) > a"));
		flights.click();	
	//Hotels
		Thread.sleep(2000);
		WebElement hotel=driver.findElement(By.cssSelector("#navbarSupportedContent > div.nav-item--left.ms-lg-5 > ul > li:nth-child(2) > a"));
		hotel.click();
	//Tours
		Thread.sleep(2000);
		WebElement tours=driver.findElement(By.cssSelector("#navbarSupportedContent > div.nav-item--left.ms-lg-5 > ul > li:nth-child(3) > a"));
		tours.click();
	
	//Blog
		Thread.sleep(2000);
		WebElement blog=driver.findElement(By.cssSelector("#navbarSupportedContent > div.nav-item--left.ms-lg-5 > ul > li:nth-child(5) > a"));
		blog.click();
		driver.quit();
		

	}

}
