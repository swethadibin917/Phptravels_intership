package com.phptravels.agent.end;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class Agent_Login {

	public static void main(String[] args) throws InterruptedException
	{

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\91999\\Downloads\\chromedriver-116\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
	    driver.get("https://www.phptravels.net");
		driver.manage().window().maximize();
		
		
//1)Login using the credentials. Check for valid and invalid test cases		
	   
		//valid email and password
	   //click Account button
		driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/div[2]/ul/li[3]/a/strong")).click();
	  //click login button
		driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/div[2]/ul/li[3]/ul/li[1]/a")).click();
		Thread.sleep(2000);
		WebElement email=driver.findElement(By.id("email"));
		email.sendKeys("agent@phptravels.com");
		WebElement pwd=driver.findElement(By.id("password"));
		pwd.sendKeys("demoagent");
		Thread.sleep(2000);
		WebElement login=driver.findElement(By.id("submitBTN"));
		login.click();
		System.out.println("login successfully");
	   
		//valid email and invalid password
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/header/div/div[2]/div[2]/ul/li[3]/a")).click();
		driver.findElement(By.linkText("Logout")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/div[2]/ul/li[3]/a/strong")).click();
		driver.findElement(By.xpath(" //*[@id=\"navbarSupportedContent\"]/div[2]/ul/li[3]/ul/li[1]/a")).click();
		Thread.sleep(2000);
		WebElement emailin=driver.findElement(By.id("email"));
		emailin.sendKeys("agent@phptravels.com");
		Thread.sleep(2000);
		WebElement pwdin=driver.findElement(By.id("password"));
		pwdin.sendKeys("demoagnt");
		Thread.sleep(2000);
		WebElement loginin=driver.findElement(By.id("submitBTN"));
		loginin.click();
		System.out.println("please check your email and password");
	
		//invalid email and valid password
		Thread.sleep(3000);
		WebElement emailinv=driver.findElement(By.id("email"));
		emailinv.sendKeys("agent@phptravs.com");
		WebElement pwdinv=driver.findElement(By.id("password"));
		pwdinv.sendKeys("demoagent");
		Thread.sleep(2000);
		WebElement logininv=driver.findElement(By.id("submitBTN"));
		logininv.click();
		System.out.println("please check your email and password..");
	
		//invalid email and invalid password
		Thread.sleep(3000);
		WebElement emailinva=driver.findElement(By.id("email"));
		emailinva.sendKeys("agent@phptravs.com");
		WebElement pwdinva=driver.findElement(By.id("password"));
		pwdinva.sendKeys("demoakjgent");
		Thread.sleep(2000);
		WebElement logininva=driver.findElement(By.id("submitBTN"));
		logininva.click();
		System.out.println("please check your email and password..");
		Thread.sleep(3000);
		driver.close();



	}

}
