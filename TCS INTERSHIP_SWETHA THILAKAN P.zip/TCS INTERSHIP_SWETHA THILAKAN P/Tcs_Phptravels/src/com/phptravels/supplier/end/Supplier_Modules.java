package com.phptravels.supplier.end;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Supplier_Modules {

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\91999\\Downloads\\chromedriver-116\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.phptravels.net/login");
		driver.manage().window().maximize();
//5)Check whether the modules "Flight","Visa", "Tours", "Booking"are displayed and can be clicked
	//vaild email and password
	Thread.sleep(2000);
	WebElement acc=driver.findElement(By.cssSelector("#navbarSupportedContent > div.nav-item--right > ul > li:nth-child(3) > a"));
	acc.click();
	WebElement login=driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/div[2]/ul/li[3]/ul/li[1]/a"));
	login.click();
	Thread.sleep(3000);
	WebElement email=driver.findElement(By.xpath("//input[@name='email']"));
	email.sendKeys("supplier@phptravels.com");
	WebElement pwd=driver.findElement(By.xpath("//input[@name='password']"));
	pwd.sendKeys("demosupplier");
	driver.findElement(By.xpath("//button[@id='submitBTN']")).click();
	Thread.sleep(3000);
//Click Flights module
	WebElement flights=driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/div[1]/ul/li[1]/a"));
	flights.click();
//click Tours module
	Thread.sleep(3000);
	WebElement tours=driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/div[1]/ul/li[3]/a"));
	tours.click();
//Click Bookings module
	Thread.sleep(3000);
	WebElement acc1=driver.findElement(By.cssSelector("#navbarSupportedContent > div.nav-item--right > ul > li:nth-child(3) > a"));
	acc1.click();
	Thread.sleep(3000);
	WebElement booking=driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/div[2]/ul/li[3]/ul/li[2]/a"));
	booking.click();
	driver.close();

	}

}
